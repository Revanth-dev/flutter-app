import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'context/auth_provider.dart';
import 'components/login.dart'; // Your login component
import 'components/signup_form_details.dart'; // Your signup component
import 'components/logged_in_user.dart'; // Your logged-in user component
import 'components/employee_home.dart'; // Employee Home component
import 'components/employee_profile.dart'; // Employee Profile component
import 'components/all_feedbacks.dart'; // All Feedbacks component
import 'components/employee_create_feedback.dart'; // Employee Create Feedback component
import 'components/employee_visited_merchants.dart'; // Employee Visited Merchants component
import 'components/admin_home.dart'; // Admin Home component
import 'components/admin_view_all_employees.dart'; // Admin View All Employees component
import 'components/admin_view_all_feedbacks.dart'; // Admin View All Feedbacks component
import 'components/admin_view_all_merchants.dart'; // Admin View All Merchants component
import 'components/admin_view_all_devices.dart'; // Admin View All Devices component
import 'components/admin_profile.dart'; // Admin Profile component
import 'components/admin_create_resource.dart'; // Admin Create Resource component

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AuthProvider(),
      child: MaterialApp(
        title: 'Your App',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF343541), // Dark gray background
        ),
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          '/': (context) => Login(), // Initial route to Login
          '/signup': (context) => SignupFormDetails(),
          '/loggeduser': (context) => LoggedInUser(),
          
          // Employee routes
          '/employee/home': (context) => EmployeeHome(),
          '/loggeduser/employeeprofile': (context) => EmployeeProfile(),
          
          '/loggeduser/createfeedback': (context) => FeedbackForm(),
          '/loggeduser/feedbacks': (context) => EmployeeMerchantVisitTable(),

          // Admin routes
          '/admin/home': (context) => AdminHome(),
          '/aloggeduser/viewallemployees': (context) => EmployeeListPage(),
          '/aloggeduser/viewallfeedbacks': (context) => AdminFeedbacksPage(),
          '/aloggeduser/viewallmerchants': (context) => AdminViewAllMerchants(),
          '/admin/view-all-devices': (context) => AdminViewAllDevices(),
          '/aloggeduser/profile': (context) => AdminProfile(),
          '/aloggeduser/createemployee': (context) => AdminCreateResource(),
        },
      ),
    );
  }
}
