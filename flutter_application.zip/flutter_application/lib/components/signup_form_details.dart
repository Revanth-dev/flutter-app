import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../context/auth_provider.dart';

class SignupFormDetails extends StatefulWidget {
  const SignupFormDetails({super.key});

  @override
  _SignupFormDetailsState createState() => _SignupFormDetailsState();
}

class _SignupFormDetailsState extends State<SignupFormDetails> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController payswiffIdController = TextEditingController();
  final TextEditingController designationController = TextEditingController();
  
  bool isError = false;
  String errorMessage = "";

  void handleSignup() {
    // Implement validation and signup logic
    // Use Provider.of<AuthProvider>(context).login(...) for the actual login
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign Up')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: emailController, decoration: const InputDecoration(labelText: 'Email')),
            TextField(controller: phoneController, decoration: const InputDecoration(labelText: 'Phone')),
            TextField(controller: passwordController, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
            TextField(controller: payswiffIdController, decoration: const InputDecoration(labelText: 'Payswiff ID')),
            TextField(controller: designationController, decoration: const InputDecoration(labelText: 'Designation')),
            const SizedBox(height: 20),
            isError ? Text(errorMessage, style: const TextStyle(color: Colors.red)) : Container(),
            ElevatedButton(onPressed: handleSignup, child: const Text('Create Account')),
          ],
        ),
      ),
    );
  }
}
