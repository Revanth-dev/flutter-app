import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../context/auth_provider.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _employeeIdController = TextEditingController();
  String? _errorMessage;

  // Sample function to get employee type based on provided information
  String determineEmployeeType(String username) {
    // Here you could implement logic to determine the employee type, like an API call.
    // For now, let's use a simple condition for demonstration.
    return username == 'admin' ? 'admin' : 'employee';
  }

  void _login() {
    final username = _usernameController.text.trim();
    final employeeId = _employeeIdController.text.trim();

    if (username.isNotEmpty && employeeId.isNotEmpty) {
      final employeeType = determineEmployeeType(username);

      Provider.of<AuthProvider>(context, listen: false).login(
        username,
        employeeId,
        employeeType,
        context,
      );

      // No need for additional navigation here, as it’s handled in AuthProvider
    } else {
      setState(() {
        _errorMessage = 'Please enter both username and employee ID';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(labelText: 'Username'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _employeeIdController,
              decoration: const InputDecoration(labelText: 'Employee ID'),
            ),
            if (_errorMessage != null) ...[
              const SizedBox(height: 10),
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: const Text('Login'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/signup');
              },
              child: const Text('Create Account'),
            ),
          ],
        ),
      ),
    );
  }
}
