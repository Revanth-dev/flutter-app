import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:excel/excel.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminCreateResource extends StatefulWidget {
  @override
  _AdminCreateResourceState createState() => _AdminCreateResourceState();
}

class _AdminCreateResourceState extends State<AdminCreateResource> {
  PlatformFile? selectedFile;
  bool uploadConfirmed = false;
  double progress = 0;
  List<Map<String, dynamic>> results = [];
  bool isCreating = false;

  Future<void> handleFileSelect() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );

    if (result != null) {
      final file = result.files.single;
      final confirmUpload = await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Confirm Upload'),
          content: Text('Are you sure you want to upload this file: ${file.name}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text('Confirm'),
            ),
          ],
        ),
      );
      if (confirmUpload) {
        setState(() {
          selectedFile = file;
          uploadConfirmed = true;
        });
      }
    }
  }

  Future<List<Map<String, dynamic>>> readFile(PlatformFile file) async {
    try {
      final bytes = file.bytes;
      var excel = Excel.decodeBytes(bytes!);
      var sheet = excel.tables[excel.tables.keys.first];
      List<Map<String, dynamic>> jsonData = [];

      for (var row in sheet!.rows.skip(1)) {
        jsonData.add({
          'Employee Payswiff ID': row[0]?.value,
          'Employee Name': row[1]?.value,
          'Employee Email': row[2]?.value,
          'Employee Phone Number': row[3]?.value,
          'Employee Designation': row[4]?.value,
          'Employee Type': row[5]?.value,
        });
      }
      return jsonData;
    } catch (e) {
      throw Exception('Error parsing the Excel file. Please ensure it is formatted correctly.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Admin Create Resource')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Upload Employee Data',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.blueGrey),
                ),
                SizedBox(height: 12),
                Text(
                  'Please select an Excel (.xlsx) file containing employee data. Each row should have details for one employee.',
                  style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 30),
                ElevatedButton.icon(
                  icon: Icon(Icons.upload_file, size: 24),
                  label: Text(
                    uploadConfirmed ? 'File Selected: ${selectedFile!.name}' : 'Select Excel File',
                    style: TextStyle(fontSize: 16),
                  ),
                  onPressed: handleFileSelect,
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20), backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                if (uploadConfirmed) ...[
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await handleCreateEmployees();
                    },
                    child: Text(
                      'Create Employees',
                      style: TextStyle(fontSize: 16),
                    ),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20), backgroundColor: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
                if (isCreating) ...[
                  SizedBox(height: 30),
                  CircularProgressIndicator(
                    value: progress / 100,
                    backgroundColor: Colors.grey[200],
                    color: Colors.blue,
                    strokeWidth: 6,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Progress: ${progress.toStringAsFixed(0)}%',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ],
                SizedBox(height: 20),
                if (results.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20.0),
                    child: Column(
                      children: [
                        Text(
                          'Results',
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.blueGrey),
                        ),
                        SizedBox(height: 12),
                        Container(
                          height: 300,
                          child: ListView.builder(
                            itemCount: results.length,
                            itemBuilder: (context, index) {
                              final result = results[index];
                              return Card(
                                margin: EdgeInsets.symmetric(vertical: 6),
                                color: result['status'] == 'Created' ? Colors.green[50] : Colors.red[50],
                                child: ListTile(
                                  title: Text(
                                    result['Employee']['Employee Name'] ?? 'Unknown',
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                  subtitle: Text(
                                    result['status'],
                                    style: TextStyle(
                                      color: result['status'] == 'Created' ? Colors.green : Colors.red,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  trailing: result['errors'] != null
                                      ? Icon(Icons.error, color: Colors.red)
                                      : Icon(Icons.check_circle, color: Colors.green),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  
  handleCreateEmployees() {}
}
