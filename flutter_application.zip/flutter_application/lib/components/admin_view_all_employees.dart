import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EmployeeListPage extends StatefulWidget {
  const EmployeeListPage({super.key});

  @override
  _EmployeeListPageState createState() => _EmployeeListPageState();
}

class _EmployeeListPageState extends State<EmployeeListPage> {
  List<Map<String, dynamic>> employees = [];
  Map<String, dynamic>? selectedEmployee;
  bool isLoading = true;
  String error = '';
  bool showErrorModal = false;

  @override
  void initState() {
    super.initState();
    fetchEmployees();
  }

  Future<void> fetchEmployees() async {
    try {
      // Replace with actual authorization token if needed
      final String token = "your_token_here";  // Or fetch from storage if required

      final response = await http.get(
        Uri.parse('http://localhost:8080/api/employees/all'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          employees = List<Map<String, dynamic>>.from(data);
          isLoading = false;
        });
      } else {
        setState(() {
          error = 'Failed to load employee data';
          isLoading = false;
          showErrorModal = true;
        });
      }
    } catch (e) {
      setState(() {
        error = 'Error: $e';
        isLoading = false;
        showErrorModal = true;
      });
    }
  }

  void _showEmployeeModal(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Employee Details'),
          content: selectedEmployee != null
              ? SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Payswiff ID: ${selectedEmployee!['employeePayswiffId']}'),
                      Text('Name: ${selectedEmployee!['employeeName']}'),
                      Text('Email: ${selectedEmployee!['employeeEmail']}'),
                      Text('Phone Number: ${selectedEmployee!['employeePhoneNumber']}'),
                      Text('Designation: ${selectedEmployee!['employeeDesignation']}'),
                      Text('Employee Type: ${selectedEmployee!['employeeType']}'),
                      Text('Creation Time: ${DateTime.parse(selectedEmployee!['employeeCreationTime']).toLocal()}'),
                      Text('Updation Time: ${DateTime.parse(selectedEmployee!['employeeUpdationTime']).toLocal()}'),
                    ],
                  ),
                )
              : const Text('No details available'),
          actions: [
            TextButton(
              child: const Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Employee List'),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : showErrorModal
              ? Center(child: Text(error, style: const TextStyle(color: Colors.red)))
              : employees.isNotEmpty
                  ? ListView.builder(
                      itemCount: employees.length,
                      itemBuilder: (context, index) {
                        final employee = employees[index];
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedEmployee = employee;
                            });
                            _showEmployeeModal(context);
                          },
                          child: Card(
                            margin: const EdgeInsets.all(8.0),
                            child: ListTile(
                              title: Text('Payswiff ID: ${employee['employeePayswiffId']}'),
                              subtitle: Text('Name: ${employee['employeeName']}'),
                              trailing: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text('Phone: ${employee['employeePhoneNumber']}'),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    )
                  : const Center(child: Text('No employees available')),
    );
  }
}
