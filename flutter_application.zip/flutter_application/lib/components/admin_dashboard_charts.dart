import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class AdminDashboardCharts extends StatelessWidget {
  final List<_ChartData> barChartData = [
    _ChartData('Jan', 35),
    _ChartData('Feb', 28),
    _ChartData('Mar', 34),
    _ChartData('Apr', 32),
    _ChartData('May', 40),
  ];

  final List<_ChartData> pieChartData = [
    _ChartData('Feedback', 40),
    _ChartData('Employees', 30),
    _ChartData('Merchants', 30),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Bar Chart
        Expanded(
          child: SfCartesianChart(
            primaryXAxis: CategoryAxis(),
            title: ChartTitle(text: 'Monthly Data Overview'),
            legend: Legend(isVisible: true),
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <ChartSeries<_ChartData, String>>[
              ColumnSeries<_ChartData, String>(
                dataSource: barChartData,
                xValueMapper: (_ChartData data, _) => data.x,
                yValueMapper: (_ChartData data, _) => data.y,
                name: 'Data',
                color: Colors.blue,
              )
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Pie Chart
        Expanded(
          child: SfCircularChart(
            title: ChartTitle(text: 'Resource Distribution'),
            legend: Legend(isVisible: true),
            series: <CircularSeries>[
              PieSeries<_ChartData, String>(
                dataSource: pieChartData,
                xValueMapper: (_ChartData data, _) => data.x,
                yValueMapper: (_ChartData data, _) => data.y,
                dataLabelSettings: DataLabelSettings(isVisible: true),
              )
            ],
          ),
        ),
      ],
    );
  }
}

class _ChartData {
  _ChartData(this.x, this.y);
  final String x;
  final double y;
}
