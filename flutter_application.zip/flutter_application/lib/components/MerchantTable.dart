import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class MerchantTable extends StatefulWidget {
  @override
  _MerchantTableState createState() => _MerchantTableState();
}

class _MerchantTableState extends State<MerchantTable> {
  List<Map<String, dynamic>> merchants = [];
  String? error;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchMerchants();
  }

  Future<void> fetchMerchants() async {
    setState(() {
      isLoading = true;
      error = null;
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("authToken"); // Adjust key as necessary

      if (token == null) {
        throw Exception("Authorization token is missing");
      }

      final response = await http.get(
        Uri.parse('http://localhost:8080/api/merchants/all'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        List<dynamic> data = jsonDecode(response.body);
        setState(() {
          merchants = List<Map<String, dynamic>>.from(data);
          isLoading = false;
        });
      } else {
        handleErrorResponse(response.statusCode);
      }
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
      showErrorDialog();
    }
  }

  void handleErrorResponse(int statusCode) {
    String errorMessage;
    if (statusCode == 401) {
      errorMessage = 'Unauthorized access. Please log in.';
    } else if (statusCode == 403) {
      errorMessage = 'Access forbidden. You do not have permission.';
    } else if (statusCode == 500) {
      errorMessage = 'Internal server error. Please try again later.';
    } else {
      errorMessage = 'An error occurred';
    }
    setState(() {
      error = errorMessage;
      isLoading = false;
    });
    showErrorDialog();
  }

  void showErrorDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Error"),
        content: Text(error ?? 'An unknown error occurred'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Merchant List')),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : merchants.isEmpty
              ? Center(child: Text("Data is not available"))
              : SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(label: Text('Merchant ID')),
                      DataColumn(label: Text('Email')),
                      DataColumn(label: Text('Phone Number')),
                      DataColumn(label: Text('Business Name')),
                      DataColumn(label: Text('Business Type')),
                    ],
                    rows: merchants.map((merchant) {
                      return DataRow(
                        cells: [
                          DataCell(Text(merchant['merchantId'].toString())),
                          DataCell(Text(merchant['merchantEmail'] ?? '')),
                          DataCell(Text(merchant['merchantPhone'] ?? '')),
                          DataCell(Text(merchant['merchantBusinessName'] ?? '')),
                          DataCell(Text(merchant['merchantBusinessType'] ?? '')),
                        ],
                      );
                    }).toList(),
                  ),
                ),
    );
  }
}
