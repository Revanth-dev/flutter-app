import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminViewAllMerchants extends StatefulWidget {
  const AdminViewAllMerchants({super.key});

  @override
  _AdminViewAllMerchantsState createState() => _AdminViewAllMerchantsState();
}

class _AdminViewAllMerchantsState extends State<AdminViewAllMerchants> {
  List<Map<String, dynamic>> merchants = [];
  bool isLoading = true;
  String error = '';

  @override
  void initState() {
    super.initState();
    fetchMerchants();
  }

  Future<void> fetchMerchants() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:8080/api/merchants/all'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          merchants = List<Map<String, dynamic>>.from(data);
          isLoading = false;
        });
      } else {
        setState(() {
          error = 'Failed to load merchants';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        error = 'Error: $e';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Merchants'),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : error.isNotEmpty
              ? Center(child: Text(error, style: TextStyle(color: Colors.red)))
              : merchants.isNotEmpty
                  ? ListView.builder(
                      itemCount: merchants.length,
                      itemBuilder: (context, index) {
                        final merchant = merchants[index];
                        return Card(
                          margin: EdgeInsets.all(8.0),
                          child: ListTile(
                            title: Text(merchant['merchantBusinessName']),
                            subtitle: Text(merchant['merchantEmail']),
                            trailing: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('Phone: ${merchant['merchantPhone']}'),
                                Text('Business Type: ${merchant['merchantBusinessType']}'),
                              ],
                            ),
                          ),
                        );
                      },
                    )
                  : const Center(child: Text('No merchants available')),
    );
  }
}
