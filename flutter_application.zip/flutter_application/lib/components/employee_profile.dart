import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EmployeeProfile extends StatefulWidget {
  @override
  _EmployeeProfileState createState() => _EmployeeProfileState();
}

class _EmployeeProfileState extends State<EmployeeProfile> {
  Map<String, dynamic>? employee;
  String? error;

  // Fetch employee data
  Future<void> fetchEmployeeData() async {
    try {
      final response = await http.get(Uri.parse('http://localhost:8080/api/employees/get'));

      if (response.statusCode != 200) {
        throw Exception('Failed to load employee data');
      }

      setState(() {
        employee = json.decode(response.body);
      });
    } catch (e) {
      setState(() {
        error = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchEmployeeData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Employee Profile')),
      body: Center(
        child: employee != null
            ? Card(
                margin: EdgeInsets.all(16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Profile Image or Icon
                      employee!['employeePhotoUrl'] != null
                          ? Image.network(
                              employee!['employeePhotoUrl'],
                              width: 150,
                              height: 150,
                              fit: BoxFit.cover,
                            )
                          : Icon(Icons.person, size: 100, color: Colors.grey),
                      SizedBox(height: 16),
                      // Employee Details
                      Text("Name: ${employee!['employeeName']}"),
                      Text("Designation: ${employee!['employeeDesignation']}"),
                      Text("Email: ${employee!['employeeEmail']}"),
                      Text("Phone: ${employee!['employeePhoneNumber']}"),
                      Text("Payswiff ID: ${employee!['employeePayswiffId']}"),
                      Text("Employee Type: ${employee!['employeeType']}"),
                      Text("Roles: ${employee!['roles'].join(', ')}"),
                      Text("Creation Time: ${DateTime.parse(employee!['employeeCreationTime']).toLocal()}"),
                      Text("Updation Time: ${DateTime.parse(employee!['employeeUpdationTime']).toLocal()}"),
                    ],
                  ),
                ),
              )
            : error != null
                ? Text('Error: $error', style: TextStyle(color: Colors.red))
                : CircularProgressIndicator(),
      ),
    );
  }
}
  