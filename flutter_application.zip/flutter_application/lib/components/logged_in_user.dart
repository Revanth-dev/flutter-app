import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../context/auth_provider.dart';
import 'employee_home.dart'; // Assuming this is where you want to navigate to

class LoggedInUser extends StatelessWidget {
  const LoggedInUser({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, ${authProvider.username}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout(context); // Log out the user and navigate to login
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('You are logged in!', style: TextStyle(fontSize: 24)),
            ElevatedButton(
              onPressed: () {
                // Navigate to the employee home page
                Navigator.pushReplacementNamed(context, '/employee/home');
              },
              child: const Text('Go to Home'),
            ),
          ],
        ),
      ),
    );
  }
}
