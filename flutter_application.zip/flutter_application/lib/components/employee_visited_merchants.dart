import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class EmployeeMerchantVisitTable extends StatefulWidget {
  @override
  _EmployeeMerchantVisitTableState createState() => _EmployeeMerchantVisitTableState();
}

class _EmployeeMerchantVisitTableState extends State<EmployeeMerchantVisitTable> {
  List<Map<String, dynamic>> merchantVisits = [];
  String? expandedMerchantId; // Track expanded rows
  String? error; // Error message

  // Fetch feedbacks from API
  Future<void> fetchFeedbacks() async {
    try {
      final response = await http.get(Uri.parse('http://localhost:8080/api/feedback/getallfeedbacks'));

      if (response.statusCode != 200) {
        throw Exception('Failed to load data');
      }

      final feedbackData = json.decode(response.body) as List;
      final uniqueMerchants = <String, bool>{};
      final visits = feedbackData.fold<List<Map<String, dynamic>>>([], (acc, feedback) {
        final merchantId = feedback['feedbackMerchant']['merchantId'];

        if (!uniqueMerchants.containsKey(merchantId)) {
          uniqueMerchants[merchantId] = true;
          acc.add({
            'merchantId': merchantId,
            'merchantName': feedback['feedbackMerchant']['merchantEmail'],
            'visitDate': DateTime.parse(feedback['feedbackCreationTime']).toLocal().toString(),
            'contact': feedback['feedbackMerchant']['merchantPhone'],
          });
        }
        return acc;
      });

      setState(() {
        merchantVisits = visits;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchFeedbacks();
  }

  // Toggle the expanded view for merchant rows
  void toggleRow(String merchantId) {
    setState(() {
      expandedMerchantId = expandedMerchantId == merchantId ? null : merchantId;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Merchant Visits by Employee')),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (error != null) // Display error message if it exists
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  error!,
                  style: TextStyle(color: Colors.red, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ),
            Expanded(
              child: merchantVisits.isNotEmpty
                  ? ListView.builder(
                      itemCount: merchantVisits.length,
                      itemBuilder: (context, index) {
                        final visit = merchantVisits[index];
                        final isExpanded = expandedMerchantId == visit['merchantId'];
                        return Column(
                          children: [
                            ListTile(
                              title: Text('Merchant Name: ${visit['merchantName']}'),
                              subtitle: Text('Visit Date: ${visit['visitDate']}'),
                              onTap: () => toggleRow(visit['merchantId']),
                            ),
                            if (isExpanded)
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                child: Text('Contact: ${visit['contact']}'),
                              ),
                            Divider(),
                          ],
                        );
                      },
                    )
                  : Center(
                      child: Text(
                        'Data not available',
                        style: TextStyle(color: Colors.red, fontSize: 16),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
