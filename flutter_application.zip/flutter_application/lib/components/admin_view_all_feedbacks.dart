import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminFeedbacksPage extends StatefulWidget {
  const AdminFeedbacksPage({super.key});

  @override
  _AdminFeedbacksPageState createState() => _AdminFeedbacksPageState();
}

class _AdminFeedbacksPageState extends State<AdminFeedbacksPage> {
  List<Map<String, dynamic>> feedbacks = [];
  Map<String, dynamic>? selectedFeedback;
  bool isLoading = true;
  String error = '';
  bool showErrorModal = false;

  @override
  void initState() {
    super.initState();
    fetchFeedbacks();
  }

  Future<void> fetchFeedbacks() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:8080/api/feedback/getallfeedbacks'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          feedbacks = List<Map<String, dynamic>>.from(data);
          isLoading = false;
        });
      } else {
        setState(() {
          error = 'Failed to load feedbacks';
          isLoading = false;
          showErrorModal = true;
        });
      }
    } catch (e) {
      setState(() {
        error = 'Error: $e';
        isLoading = false;
        showErrorModal = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Feedbacks'),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : showErrorModal
              ? Center(child: Text(error, style: const TextStyle(color: Colors.red)))
              : feedbacks.isNotEmpty
                  ? ListView.builder(
                      itemCount: feedbacks.length,
                      itemBuilder: (context, index) {
                        final feedback = feedbacks[index];
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedFeedback = feedback;
                            });
                            _showFeedbackModal(context);
                          },
                          child: Card(
                            margin: const EdgeInsets.all(8.0),
                            child: ListTile(
                              title: Text('Feedback ID: ${feedback['feedbackId']}'),
                              subtitle: Text('Employee ID: ${feedback['feedbackEmployee']['employeeId']}'),
                              trailing: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text('Rating: ${feedback['feedbackRating']}'),
                                  feedback['feedbackImage1'] != null
                                      ? Image.network(
                                          feedback['feedbackImage1'],
                                          width: 30,
                                          height: 30,
                                          fit: BoxFit.cover,
                                        )
                                      : const Text('No Image'),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    )
                  : const Center(child: Text('No feedbacks available')),
    );
  }

  void _showFeedbackModal(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Feedback Details'),
          content: selectedFeedback != null
              ? SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Feedback ID: ${selectedFeedback!['feedbackId']}'),
                      Text('Employee ID: ${selectedFeedback!['feedbackEmployee']['employeeId']}'),
                      Text('Merchant ID: ${selectedFeedback!['feedbackMerchant']['merchantId']}'),
                      Text('Device ID: ${selectedFeedback!['feedbackDevice']['deviceId']}'),
                      Text('Rating: ${selectedFeedback!['feedbackRating']}'),
                      Text('Feedback Description: ${selectedFeedback!['feedback']}'),
                      Text('Merchant Name: ${selectedFeedback!['feedbackMerchant']['merchantBusinessName']}'),
                      Text('Employee Name: ${selectedFeedback!['feedbackEmployee']['employeeName']}'),
                      Text('Device Model: ${selectedFeedback!['feedbackDevice']['deviceModel']}'),
                      if (selectedFeedback!['feedbackImage1'] != null)
                        Image.network(selectedFeedback!['feedbackImage1']),
                    ],
                  ),
                )
              : const Text('No details available'),
          actions: [
            TextButton(
              child: const Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
