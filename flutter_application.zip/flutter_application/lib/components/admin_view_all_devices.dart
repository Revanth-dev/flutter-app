import 'package:flutter/material.dart';

class AdminViewAllDevices extends StatelessWidget {
  const AdminViewAllDevices({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Devices'),
      ),
      body: const Center(
        child: Text('List of all devices will be displayed here.'),
      ),
    );
  }
}
