import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../context/auth_provider.dart';

class AdminProfile extends StatelessWidget {
  const AdminProfile({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Username: ${authProvider.username}', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            Text('Employee ID: ${authProvider.employeeId}', style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            Text('Employee Type: ${authProvider.employeeType}', style: const TextStyle(fontSize: 20)),
            // Additional fields as necessary
          ],
        ),
      ),
    );
  }
}
