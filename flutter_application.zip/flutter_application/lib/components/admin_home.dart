import 'package:flutter/material.dart';
import 'admin_dashboard_charts.dart'; // Import the charts

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Admin Dashboard')),
        backgroundColor: Colors.blueGrey,
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/aloggeduser/viewallemployees');
            },
            child: const Text(
              'View All Employees',
              style: TextStyle(color: Colors.white),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/aloggeduser/viewallfeedbacks');
            },
            child: const Text(
              'View All Feedbacks',
              style: TextStyle(color: Colors.white),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/aloggeduser/viewallmerchants');
            },
            child: const Text(
              'View All Merchants',
              style: TextStyle(color: Colors.white),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/aloggeduser/createemployee');
            },
            child: const Text(
              'Create Employee',
              style: TextStyle(color: Colors.white),
            ),
          ),
          // Profile Button
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/aloggeduser/profile');
            },
            child: const Text(
              'Profile',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: AdminDashboardCharts(),
      ),
    );
  }
}
