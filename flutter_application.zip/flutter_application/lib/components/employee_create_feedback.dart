import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class FeedbackForm extends StatefulWidget {
  @override
  _FeedbackFormState createState() => _FeedbackFormState();
}

class _FeedbackFormState extends State<FeedbackForm> {
  final TextEditingController _merchantNameController = TextEditingController();
  String? _selectedDevice;
  double _rating = 3.0; // Default rating value
  File? _image;
  final ImagePicker _picker = ImagePicker();

  final List<String> deviceNames = ['Device A', 'Device B', 'Device C'];

  // Predefined questions and answers for device feedback
  final List<Map<String, dynamic>> questions = [
    {
      'question': 'How satisfied are you with the device performance?',
      'answers': ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'],
      'selectedAnswer': null,
    },
    {
      'question': 'Was the device easy to set up?',
      'answers': ['Yes', 'No'],
      'selectedAnswer': null,
    },
    {
      'question': 'Is the device user-friendly?',
      'answers': ['Yes', 'No'],
      'selectedAnswer': null,
    },
    {
      'question': 'How would you rate the design of the device?',
      'answers': ['Excellent', 'Good', 'Average', 'Poor'],
      'selectedAnswer': null,
    },
    {
      'question': 'Would you recommend this device to others?',
      'answers': ['Yes', 'No'],
      'selectedAnswer': null,
    },
  ];

  int _currentQuestionIndex = 0;

  // Function to pick an image from the gallery or camera
  Future<void> _pickImage(ImageSource source) async {
    final XFile? pickedFile = await _picker.pickImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  // Handle Radio Button Selection for each question
  void _handleRadioValueChanged(int questionIndex, String? value) {
    setState(() {
      questions[questionIndex]['selectedAnswer'] = value;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Feedback Form'),
          backgroundColor: Colors.blueAccent,
        ),
        
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(16.0),
            child: Container(
              padding: EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blueAccent.withOpacity(0.8), Colors.blue.withOpacity(0.6)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 12.0,
                    spreadRadius: 6.0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Feedback Form Title
                  Text(
                    'Feedback Form',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: const Color.fromARGB(255, 0, 0, 0),
                    ),
                  ),
                  SizedBox(height: 24),

                  // Merchant Name Input (with neumorphic effect)
                  TextField(
                    controller: _merchantNameController,
                    decoration: InputDecoration(
                      labelText: 'Merchant Name',
                      labelStyle: TextStyle(color: const Color.fromARGB(255, 0, 0, 0)),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16.0),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                      hintText: 'Enter Merchant Name',
                      hintStyle: TextStyle(color: Colors.grey[400]),
                    ),
                    style: TextStyle(color: Colors.black),
                  ),
                  SizedBox(height: 16),

                  // Device Name Dropdown (with neumorphic effect)
                  DropdownButtonFormField<String>(
                    value: _selectedDevice,
                    items: deviceNames.map((device) {
                      return DropdownMenuItem<String>(
                        value: device,
                        child: Text(device, style: TextStyle(color: Colors.black)),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedDevice = value;
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Device Name',
                      labelStyle: TextStyle(color: const Color.fromARGB(255, 0, 0, 0)),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16.0),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                    ),
                  ),
                  SizedBox(height: 16),

                  // Star Rating
                  Text('Rating', style: TextStyle(fontSize: 18, color: const Color.fromARGB(255, 0, 0, 0))),
                  RatingBar.builder(
                    initialRating: _rating,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemSize: 36,
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      setState(() {
                        _rating = rating;
                      });
                    },
                  ),
                  SizedBox(height: 16),

                  // Image Upload Section with neumorphism
                  Text(
                    _image == null ? 'No image selected' : 'Image Selected',
                    style: TextStyle(fontSize: 16, color: Colors.white70),
                  ),
                  SizedBox(height: 16),
                  _image == null
                      ? Container(
                          width: 200,
                          height: 200,
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black12,
                                blurRadius: 10.0,
                                spreadRadius: 5.0,
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.image,
                            size: 100,
                            color: Colors.white70,
                          ),
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(12.0),
                          child: Image.file(
                            _image!,
                            height: 200,
                            width: 200,
                            fit: BoxFit.cover,
                          ),
                        ),
                  SizedBox(height: 20),  // Added space between upload and question buttons

                  // Upload Buttons (Retaining both buttons)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Camera Button
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15), backgroundColor: const Color.fromARGB(255, 1, 1, 2),
                        ),
                        onPressed: () => _pickImage(ImageSource.camera),
                        icon: Icon(Icons.camera_alt),
                        label: Text('Take Photo'),
                      ),
                      SizedBox(width: 10),
                      // Gallery Button
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15), backgroundColor: const Color.fromARGB(255, 1, 1, 2),
                        ),
                        onPressed: () => _pickImage(ImageSource.gallery),
                        icon: Icon(Icons.photo_library),
                        label: Text('Choose from Gallery'),
                      ),
                    ],
                  ),
                  SizedBox(height: 24), // Space between buttons and questions

                  // Question Section - Displaying the questions
                  if (_currentQuestionIndex < questions.length)
                    Column(
                      children: [
                        Text(
                          questions[_currentQuestionIndex]['question'],
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,  // Making the question text bold
                            color: Colors.black,  // Black color for question text
                          ),
                        ),
                        SizedBox(height: 16),
                        Column(
                          children: questions[_currentQuestionIndex]['answers']
                              .map<Widget>((answer) {
                            return RadioListTile<String>(
                              title: Text(answer, style: TextStyle(color: Colors.black)),
                              value: answer,
                              groupValue: questions[_currentQuestionIndex]['selectedAnswer'],
                              onChanged: (value) {
                                _handleRadioValueChanged(_currentQuestionIndex, value);
                              },
                              activeColor: Colors.amber,
                            );
                          }).toList(),
                        ),
                        SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            ElevatedButton(
                              onPressed: _currentQuestionIndex > 0
                                  ? () {
                                      setState(() {
                                        _currentQuestionIndex--;
                                      });
                                    }
                                  : null,
                              child: Text('Back'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor:  Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16.0),
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  if (_currentQuestionIndex < questions.length - 1) {
                                    _currentQuestionIndex++;
                                  }
                                });
                              },
                              child: Text('Skip'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor:  Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16.0),
                                ),
                              ),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  if (_currentQuestionIndex < questions.length - 1) {
                                    _currentQuestionIndex++;
                                  } else {
                                    _currentQuestionIndex = questions.length;
                                  }
                                });
                              },
                              child: Text('Next'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor:  Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16.0),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                  // Submit Feedback Button after all questions are completed
                  if (_currentQuestionIndex == questions.length)
                    ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: Text("Feedback Submitted"),
                            content: Text("Thank you for your feedback!"),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: Text("OK"),
                              ),
                            ],
                          ),
                        );
                      },
                      child: Text('Submit Feedback'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16.0),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
