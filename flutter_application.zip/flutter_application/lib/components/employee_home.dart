import 'package:flutter/material.dart';

class EmployeeHome extends StatelessWidget {
  const EmployeeHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Employee Dashboard')),
        backgroundColor: Colors.blueGrey, // Change to your desired color
        actions: [
          // Button to create feedback
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/loggeduser/createfeedback');
            },
            child: const Text(
              'Create Feedback',
              style: TextStyle(color: Colors.white),
            ),
          ),
          // Button to view all feedbacks
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/loggeduser/feedbacks');
            },
            child: const Text(
              'View Feedbacks',
              style: TextStyle(color: Colors.white),
            ),
          ),
          // Button to view employee profile
          TextButton(
            onPressed: () {
              Navigator.pushNamed(context, '/loggeduser/employeeprofile');
            },
            child: const Text(
              'Profile',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Employee Dashboard', style: TextStyle(fontSize: 24)),
            // You can remove buttons here since you have them in the AppBar
          ],
        ),
      ),
    );
  }
}
