import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../context/auth_provider.dart';

class AdminLoggedInUser extends StatelessWidget {
  const AdminLoggedInUser({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              authProvider.logout(); // Log out the user
              Navigator.of(context).pushReplacementNamed('/'); // Redirect to login
            },
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Welcome, Admin ${authProvider.username}', style: const TextStyle(fontSize: 24)),
            // Add buttons for admin functionalities
          ],
        ),
      ),
    );
  }
}
