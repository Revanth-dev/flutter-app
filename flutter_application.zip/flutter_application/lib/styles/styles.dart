import 'package:flutter/material.dart';

class AppStyles {
  static const Color darkGray = Color(0xFF343541);
  static const TextStyle textStyle = TextStyle(
    color: Colors.white,
    fontFamily: 'Arial',
    fontSize: 16,
  );
}
