import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  String? _username;
  String? _employeeId;
  String? _employeeType;

  bool get isLoggedIn => _username != null;

  // Updated login function to accept BuildContext for navigation
  void login(String username, String employeeId, String employeeType, BuildContext context) {
    _username = username;
    _employeeId = employeeId;
    _employeeType = employeeType;
    notifyListeners(); // Notify listeners about the change

    // Redirect based on employee type
    if (_employeeType == 'employee') {
      Navigator.pushReplacementNamed(context, '/employee/home');
    } else if (_employeeType == 'admin') {
      Navigator.pushReplacementNamed(context, '/admin/home');
    }
  }

  // Logout function with navigation to login screen
  void logout(BuildContext context) {
    _username = null;
    _employeeId = null;
    _employeeType = null;
    notifyListeners(); // Notify listeners about the change

    // Redirect to login on logout
    Navigator.pushReplacementNamed(context, '/');
  }

  String? get username => _username;
  String? get employeeId => _employeeId;
  String? get employeeType => _employeeType;
}
